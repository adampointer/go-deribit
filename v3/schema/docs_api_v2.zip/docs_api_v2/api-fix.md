# FIX API

Deribit FIX API is a subset of FIX version 4.4, but also includes some tags from 5.0 version and several custom tags. Deribit uses the standard header and trailer structure for all messages. To enable the API, sign in and go to **Account > Security > API** Tab and use the checkbox. 'Access Secret' is the user's secret key provided by Deribit. Important Note: Do not reveal to anybody your 'Access Secret', as it can be used to gain full control over your account.

The FIX server can be reached at `www.deribit.com:9880`. The FIX server for the test network can be reached at `test.deribit.com:9881`.

Each request message can include:

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 8 | `BeginString` | String | Yes | Identifies beginning of new message and protocol version. Must always be first in the message. |
| 9 | `BodyLength` | Length | Yes | Message length in bytes, not including fields 8, 9 and 10. See refer to FIX specification on how to compute this field. Must always be the first field in the message. |
| 35 | `MsgType` | String | Yes | The type of the message. See below for available types |
| 49 | `SenderCompID` | String | Yes | A user defined client name |
| 56 | `TargetCompID` | String | Yes | Constant value: `DERIBITSERVER` |
| 34 | `MsgSeqNum` | SeqNum | Yes | A sequence number for the message, starts with 1, and must be incremented by 1 for every message. |
| 52 | `SendingTime` | UTCTimestamp | No | The time the request is sent. This field is ignored by the server |
| 10 | `CheckSum` | String | Yes | The checksum of all of all preceding messages. See refer to FIX specification on how to compute this field. Must always be the last field in the message. |

Responses sent by the server will at least include:

| Tag | Name | Type |  Comments |
|---|---|---|---|
| 8 | `BeginString` | String |  Identifies beginning of new message and protocol version. Must always be first in the message. |
| 9 | `BodyLength` | Length |  Message length in bytes, not including fields 8, 9 and 10. See refer to FIX specification on how to verify this field. Must always be the first field in the message. |
| 35 | `MsgType` | String | The type of the message. See below for available types |
| 49 | `SenderCompID` | String | Constant value: `DERIBITSERVER` |
| 56 | `TargetCompID` | String | A user defined client name |
| 34 | `MsgSeqNum` | SeqNum | A server-chosen sequence number for the message. |
| 52 | `SendingTime` | UTCTimestamp | The time the request is sent. This field is ignored by the server |
| 10 | `CheckSum` | String | The checksum of all of all preceding messages. See refer to FIX specification on how to verify this field. Must always be the last field in the message. |


## `Logon`(`A`)

`Logon`(`A`) must the first message sent by the client to initiate a session. If authentication succeeds, the exchange should echo the message back to the client. If authentication fails, the exchange will respond with a `LogOut`(`5`) message with an appropriate reason.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 108 | `HeartBtInt` | int | Yes | Used to declare the timeout interval in seconds for generating heartbeats. |
| 94 | `RawDataLength` | Length | No | Number of bytes in raw data field. Not required, as the normal RawData is base64 text here |   
| 96 | `RawData` | data | Yes | The timestamp and a Base64 encoded _nonce_ (see below) |
| 553 | `Username` | String | Yes | API Access Key. This can be obtained from the API tab on your account settings. |
| 554 | `Password` | String | Yes | See below |
| 9002 | `UseWordsafeTags` | Boolean | No | If present and set to `Y`, all of the tag values for our custom tags start at 5000 instead of 100000. This can be used for FIX libraries that don't allow higher tag numbers. This will setting will apply for the remainder of the connection. For example, `Volume24h`(`100087`) would become `5078`.|
| 9001 | `CancelOnDisconnect` | Boolean | No | Boolean, to enable or disable session-level cancel on disconnect. Default - false(`N`). |

The `RawData`(`96`) tag contains a timestamp and a _nonce_, separated by an ASCII period (`.`). The _timestamp_ needs to be a strictly increasing integer. We recommend using a timestamp in milliseconds. The _nonce_ is composed base64-encoded randomly chosen bytes. For safety reasons, it is important that the _nonce_ is sufficiently long and sourced from a cryptographically secure random number generator. We recommend at least 32 bytes, but the _nonce_ can be up to 512 bytes.

The `Password`(`553`) tag should contain a base64 encoded SHA256 hash of the concatenation of the `RawData`(`96`) content and the access secret: `base64(sha256(RawData ++ access_secret))`.

`CancelOnDisconnect`(`9001`) controls "Close on Disconnect". If this tag is not provided, the default setting from the account is used.

### Response

When the login is successful, the server will echo back the request.

If the login was not successful, the server will respond with a `Logout`(`5`) message, and close the connection.

## `Logout`(`5`)

`Logout`(`5`) can be sent by either party in order to terminate a session. The sending party should always wait for the echo of the logout request before they close the socket. Closing connections in any other way is considered abnormal behaviour. Nonetheless, if `CancelOnDisconnect`(`9001`) was set at Logon, all orders will be cancelled at Logout.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 58 | `text` | String | No | Free format text string specifying the logout reason. This is ignored by the server |



## `Heartbeat`(`0`)

When either end of a FIX connection has not sent or received any data for `HeartBtInt` seconds \(as specified in the `Logon`(`A`) message\), it will transmit a `Heartbeat`(`0`) message. When either end of a FIX connection has not received any data for `HeartBtInt` seconds, it will transmit a `Test Request`(`1`) message. If there is still no response, the session should be considered lost and corrective action should be initiated.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 112 | `TestReqId` | String | Varies | The identifier when responding to `Test Request`(`1`) message. When not responding to a `Test Request`(`1`) message, this tag can be left out |

### Response

When the heartbeat has been received successfully, the server will echo back the request as confirmation.




## `Test Request`(`1`)

The Test `Request`(`1`) message forces a heartbeat from the opposing application. The opposing application responds with a `Heartbeat`(`0`) containing the `TestReqID`(`112`).

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 112 | `TestReqId` | String  | Yes | Mirrors the original request ID. |



## `Resend Request`(`2`)

The Resend `Request`(`2`) message is used by the server to initiate the retransmission of messages. This function is utilized if a sequence number gap is detected, if the receiving application lost a message, or as a function of the initialization process.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 7 | `BeginSeqNo` | Yes | The first message to repeat |
| 16 | `EndSeqNo` | Yes | The last message to repeat |





### `Reject`(`3`)

The `Reject`(`3`) message should be issued when a message is received but cannot be properly processed due to a session-level or data structure rule violation. An example of when a reject may be appropriate would be the receipt of a message with invalid basic data \(e.g. missing tags\) which successfully passes decryption.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 45 | `RefSeqNum` | SeqNum | Yes | `MsgSeqNum`(`34`) of the rejected message |
| 372 | `RefMsgType` | String | No | The `MsgType`(`35`) of the FIX message being referenced |
| 373 | `SessionRejectReason` | int |No | Code to identity reason for rejection. See FIX specification for possible values. |
| 58 | `Text` | String | No | Text string explaining the reason for rejection. |




## `Security List Request`(`x`)

The `SecurityListRequest`(`x`) message is used to return a list of securities \(instruments\) from the Deribit.

### Arguments


| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 320 | `SecurityReqId` | String | Yes | A user-generated ID for this request. This can be used to match the request to the response. |
| 559 | `SecurityListRequestType` | int | Yes | 0 or 4 – in any case list of instruments is returned |


### Response

The server will respond with a Security `List`(`y`) message, where the `SecurityReq`(`320`) is equal to that of the request.


## `Security List`(`y`)

The `SecurityList`(`y`) message is used to return a list of securities that matches the criteria specified in a Security List `Request`(`x`).

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 320 | `SecurityReqId` | String | Yes | The `SecurityReqId`(`320`) of the request that this is a response for |
| 322 | `SecurityResponseID` | String | Yes | Identifier for the Security `List`(`x`) message |
| 560 | `SecurityRequestResult` | int | Yes | 0 indicates a successful response. This is the only possible value in the Deribit FIX API |
| 146 | `NoRelatedSym` | int | No | Specifies the number of repeating instruments specified |
| =&gt;55 | `Symbol` | String | No | Common, "human understood" representation of the security, e.g., `BTC-28JUL17`, see instrument naming convention |
| =&gt;107 | `SecurityDesc` | String |No | Free form security description. At the time of writing, this is either 'future' or 'option' |
| =&gt;167 | `SecurityType` | String |No | `FUT` or `OPT` |
| =&gt;201 | `PutOrCall` | int | No | Used to express option right, 0 – put, 1 – call. |
| =&gt;202 | `StrikePrice` | Price | No | Strike price |
| =&gt;947 | `StrikeCurrency` | Currency | No | Strike Currency |
| =&gt;15 | `Currency` | Currency | No | Currency of option |
| =&gt;2576 | `InstrumentPricePrecision`  | int | No | number of decimal places for instrument prices \(usually 4 for options, 2 for futures\) |
| =&gt;969 | `MinPriceIncrement`  | float | No | Minimum price tick for a given Instrument |
| =&gt;311 | `UnderlyingSymbol` | String | No | Underlyig symbol for options. |
| =&gt;225 | `IssueDate` | UTCTimestamp | No | Date instrument was issued. |
| =&gt;541 | `MaturityDate` | UTCTimestamp | No | Expiration date, `YYYYMMDD` |
| =&gt;1079 | `MaturityTime` | UTCTimestamp | No | Expiration time |
| =&gt;562 | `MinTradeVol` | Qty | No | The minimum trading volume for a security |
| =&gt;63 | `SettlType` | String | No | Indicates order settlement period. E.g., `M1` – month, `W1` – week, `W2` – 2 weeks etc |
| =&gt;120 | `SettlCurrency` | Currency | No | Currency code of settlement denomination. |
| =&gt;479 | `CommCurrency` | Currency | No | Specifies currency to be use for Commission. |




## `Market Data Request`(`V`)

`Market Data Request`(`V`) can be used to request market data in snapshot or the incremental form. Deribit uses his message for order book requests and its change notification.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 55 | `Symbol` | String | Yes | Instrument symbol |
| 262 | `MdReqId` | String |Yes | Unique ID assigned to this request. |
| 263 | `SubscriptionRequestType` | int |Yes | 0 = Snapshot, 1 = Snapshot + Subscribe, 2 = Unsubscribe |
| 264 | `MarketDepth` | int |No | Default 20 |
| 265 | `MDUpdateType` | int | when `SubscriptionRequestType=1` | The type of update to subscribe to. |
| 100007 | `DeribitTradeAmount` | int | No | Amount of trades returned in the snapshot response to request for snapshot of recent trades, default 20, maximum  1000 |
| 100008 | `DeribitSinceTimestamp` | int |No | UTC Timestamp in milliseconds \(integer number of milliseconds\), if specified, the response returns the trades happened since that timestamp, applicable to the request for recent trades snapshot |
|  | Group `MDEntryTypes` |  |  |
| 267 | `NoMdEntryTypes` | int | Yes | Number of entry types in the request. |
| =&gt;269 | `MDEntryType` | int | Yes | 0 = Bid \(Bid side of the order book\), 1 = Offer \(Ask side of the order book\), 2 = Trade \(Info about recent trades\) |

When requesting a subscription (`SubscriptionRequestType`=1), the only supported combinations are:

- `MDUpdateType`=1, `MarketDepth`=0. This will result a snapshot message (W) with the whole order book, followed by incremental updates (X messages) through the whole order book depth.
- `MDUpdateType`=0, `MarketDepth`=(1,10,20). This results in full refresh (W) messages, containing the entire specified order book depth. Valid values for `MarketDepth` are 1, 10, 20.

### Response

If the server is unable to supply the requested data, it will respond with a Market Data Request `Reject`(`Y`) message.

If the request called for a snapshot (i.e. `SubscriptionRequestType`(`263`)=0 or `SubscriptionRequestType`(`263`)=1), the server will respond with a Market Data - Snapshot/Full `Refresh`(`W`) message.

If the request called for a snapshot (i.e. `SubscriptionRequestType`(`263`)=0 or `SubscriptionRequestType`(`263`)=1), the server will start sending with a Market Data - Incremental `Refresh`(`X`) messages.


## `Market Data Request Reject`(`Y`)

If a Market Data `Request`(`V`) message is not accepted, the exchange responds with a Market Data Request `Reject`(`Y`) message

### Arguments


| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 58 | `Text` | String | No | Free format text string |
| 262 | `MDReqID` | String | Yes | ID of the original request |
| 281 | `MDReqRejReason` | char | Yes |  |

## `Market Data Snapshot/Full Refresh`(`W`)

Market Data Snapshot/Full `Refresh`(`W`) is used as the response to a Market Data `Request`(`V`) message.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 55 | `Symbol` | String | Yes | Instrument symbol |
| 262 | `MDReqID` | String | No | ID of the original request, if it is applicable |
| 311 | `UnderlyingSymbol` | String | For options | Underlying symbol |
| 810 | `UnderlyingPx` | Price | For options | Price of the underlying instrument |
| 231 | `ContractMultiplier` | float| No | Specifies a multiply factor to convert from contracts to total units |
| 100087 | `TradeVolume24h` | Qty | No | Defines 24h trade volume for the Symbol in the corresponding contract units |
| 100090 | `MarkPrice` | Price | No | Defines mark price for the Symbol |
| 746 | `OpenInterest` | float | No | Defines open interest for the Symbol |
| 268 | `NoMDEntries` | int | Yes | Repeating group . Specifies the number of entries in the group. |
| =&gt;279 | `MDUpdateAction` | Char | No | Type of Market Data update action. 0 = New, 1 = Change, 2 = Delete|
| =&gt;269 | `MDEntryType` | int | No | 0 = Bid \(Bid side of the order book\), 1 = Offer \(Ask side of the order book\), 2 = Trade \(in case of request for info about recent trades\) |
| =&gt;270 | `MDEntryPx` | Price | No | Price of an entry |
| =&gt;271 | `MDEntrySize` | Qty | No | Size of an entry |
| =&gt;272 | `MDEntryDate` | UTCTimestamp | No | The timestamp for trade |
| =&gt;100009 | `DeribitTradeId` | int |  No | Id of the trade, in case of the request for trades |
| =&gt;54 | `Side` | int | No | Side of trade \(1 = Buy, 2 = Sell\) |
| =&gt;58 | `Text` | String | No | The trade sequence number |
| =&gt;198 | `SecondaryOrderId` | String | No | For trade – matching order id |
| =&gt;39 | `OrdStatus` | int | No | For trade – order status \(0 = New, 1 = Partially filled, 2 = Filled, 4 = Cancelled\) |
| =&gt;100010 | `DeribitLabel` | String | No | User defined 32 character label of the order, in case of the request for trades |


## `Market Data Incremental Refresh`(`x`)

Market Data – Incremental `Refresh`(`X`) message is used for incremental updates in case of Market Data `Request`(`V`) for Snapshot + Subscribe

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 55 | `Symbol` | String | Yes | Instrument symbol |
| 262 | `MDReqID` | String | No | ID of the original request, if it is applicable |
| 231 | `ContractMultiplier` | float| No | Specifies a multiply factor to convert from contracts to total units |
| 100087 | `TradeVolume24h` | Qty | No | Defines 24h trade volume for the Symbol in the corresponding contract units |
| 100090 | `MarkPrice` | Price | No | Defines mark price for the Symbol |
| 746 | `OpenInterest` | float | No | Defines open interest for the Symbol |
| 268 | `NoMDEntries` | int | Yes | Repeating group . Specifies the number of entries in the group. |
| =&gt;279 | `MDUpdateAction` | char | No | Type of Market Data update action. Valid values: 0 = New, 1 = Change, 2 = Delete |
| =&gt;269 | `MDEntryType` | int | No | 0 = Bid \(Bid side of the order book\), 1 = Offer \(Ask side of the order book\), 2 = Trade \(in case of request for info about recent trades\) |
| =&gt;270 | `MDEntryPx` | Price | No | Price of an entry |
| =&gt;271 | `MDEntrySize` | Qty | No | Size of an entry |
| =&gt;272 | `MDEntryDate` | String | UTCTimestamp | The timestamp for trade |
| =&gt;100009 | `DeribitTradeId` | int |  No | Id of the trade, in case of the request for trades |
| =&gt;54 | `Side` | int | No | Side of trade \(1 = Buy, 2 = Sell\) |
| =&gt;37 | `OrderId` | String | No | For trade – order id |
| =&gt;198 | `SecondaryOrderId` | String | No | For trade – matching order id |
| =&gt;39 | `OrdStatus` | int | No | For trade – order status \(0 = New, 1 = Partially filled, 2 = Filled, 4 = Cancelled\) |
| =&gt;100010 | `DeribitLabel` | String | No | User defined 32 character label of the order, in case of the request for trades |
| =&gt;44 | `IndexPrice` | Price | No | For trades, this is the index price at the trade moment \(Deribit index\). |



## `New Order Single`(`D`)

The NEW ORDER `SINGLE`(`D`) is used by the client to submit new orders to the exchange. Note Deribit doesn't store client identifiers \(for the sake of speed of execution\), i.e., client software should manage matching client-server identifiers using.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 11 | `ClOrdID` | String | Yes | Unique identifier for the order as assigned by the client |
| 54 | `Side` | int | Yes | 1 = Buy, 2 = Sell |
| 38 | `OrderQty` | Qty | Yes | Order quantity |
| 44 | `Price` | Price | Yes | Price |
| 55 | `Symbol` | String | Yes | Instrument symbol, e.g., `BTC-1JAN16` |
| 18 | `ExecInst` | MultipleCharValue | No | Currently is used to place POST ONLY orders: 6 = "Participate don't initiate", and REDUCE ONLY orders: E = " Do not increase - DNI"  |
| 40 | `OrdType` | char | No | Order type. Valid values: 1 = Market, 2 = Limit. \(default Limit\) |
| 59 | `TimeInForce` | char  | No | Specifies how long the order remains in effect. Absence of this field is interpreted as "Good Till Cancel". Valid values: 1 = Good Till Cancel \(`GTC`\), 3 = Immediate or Cancel \(`IOC`\), 4 = Fill or Kill \(`FOK`\) |
| 100010 | `DeribitLabel` | String | no | A custom label for your order, max 32 characters. |
| 100012 | `DeribitAdvOrderType` | char | no | Used to create advanced order for options. If it is present: 0 = Implied Volatility Order (price defines fixed implied volatility in %) , 1 = USD Order (price defines fixed USD price of the option) |

### Response

Upon receiving a new order, the exchange responds with the Execution `Report`(`8`) message communicating whether the order was accepted or rejected.

| Tag | Name | Required | Comments |
|---|---|---|---|
| 11 | `ClOrdID` | Yes | Deribit replaces this field with the own value assigned by the server \(it is not the client id from New Order Single\) |
| 41 | `OrigClOrdId` | Yes | The original value assigned by the client in the `New Order Single`(`D`) message |
| 39 | `OrdStatus` | Yes | 0 = New, 1 = Partially filled, 2 = Filled, 8 = Rejected |
| 54 | `Side` | Yes | 1 = Buy, 2 = Sell |
| 60 | `TransactTime` | Yes | Time the transaction represented by this Execution Report occurred. Fix timestamp. |
| 151 | `LeavesQty` | Yes | Order quantity open for further execution \(`LeavesQty` = `OrderQty` - `CumQty`\) |
| 14 | `CumQty` | Yes | Total executed quantity or 0.0 |
| 38 | `OrderQty` | Yes | Order quantity |
| 40 | `OrdType` | Yes | 1 = Market, 2 = Limit, 4 = Stop Limit, S = Stop Market |
| 44 | `Price` | Yes | Price |
| 18 | `ExecInst` | No | Currently is used to mark POST ONLY orders: 6 = "Participate don't initiate", and REDUCE ONLY orders: E = " Do not increase - DNI"  |
| 103 | `OrdRejReason` | Yes |  |
| 58 | `Text` | No | Free format text string, usually exceptions |
| 207 | `SecurityExchange` | No | "Deribit" |
| 55 | `Symbol` | Yes | Instrument symbol |
| 854 | `QtyType` | No | Type of quantity specified in a quantity. Currently only 1 - `Contracts`.  |
| 231 | `ContractMultiplier` | No | Specifies a multiply factor to convert from contracts to total units |
| 6 | `AvgPx` | No | Average execution price or 0.0 if not executed yet or rejected |
| 210 | `MaxShow` | No | Maximum quantity (e.g. number of shares) within an order to be shown to other customers |
| 100012 | `DeribitAdvOrderType` | No | if it is present then it denotes advanced order for options: 0 = Implied Volatility Order, 1 = USD Order |
| 1188 | `Volatility` | No | volatility for Implied Volatility Orders (options orders with fixed volatility) |
| 839 | `PeggedPrice` | No | value of fixed USD price for USD Orders (options orders with fixed USD price) |
| 1362 | `NoFills` | No | Number of immediate fill entries for the order |
| =&gt;1363 | `FillExecID` | No | Unique identifier of execution, concatenated via '\#' symbol and trade sequence number, e.g., `BTC-28SEP18#38`. |
| =&gt;1364 | `FillPx` | No | Price of this partial fill |
| =&gt;1365 | `FillQty` | No | Quantity bought/sold on this partial fill |





## `Order Cancel Request`(`F`)

This message requests the cancellation of a particular order. If an order has been partially filled, only the remaining quantity can be cancelled. The request should be accepted only if an order can successfully be cancelled without executing further. The server generated identifiers should be used as `OrigClOrdId`, Deribit doesn't store client identifiers.

### Arguments

| Tag | Name | Required | Comments |
|---|---|---|---|
| 11 | `ClOrdID` | Yes | Order identifier |
| 41 | `OrigClOrdId` | Yes | Order identifier assigned by Deribit |

### Response on failure

`Order Cancel Reject`(`9`) is issued by the exchange upon receipt of Order Cancel `Request`(`F`) message which cannot be executed.

| Tag | Name | Required | Comments |
|---|---|---|---|
| 52 | `SendingTime` | Yes |  |
| 11 | `ClOrdID` | Yes | Order identifier |
| 41 | `OrigClOrdId` | Yes | Order identifier assigned by Deribit |
| 39 | `OrdStatus` | No | If it is applicable |
| 58 | `Text` | No | Text string explaining the reason for rejection |

### Response on success

The following `Execution Report`(`8`) is sent by the exchange upon successfully processing a cancel request.

| Tag | Name | Required | Comments |
|---|---|---|---|
| 52 | `SendingTime` | Yes |  |
| 11 | `ClOrdID` | Yes | Deribit replaces this field with the own value assigned by the server \(it is not the client id from New Order Single\) |
| 41 | `OrigClOrdId` | Yes | The original value assigned by the client in the `New Order Single`(`D`) message |
| 39 | `OrdStatus` | Yes | 0 = New, 1 = Partial, 4 = Cancelled, 8 = Rejected |
| 58 | `Text` | Yes | Text string describing the result |

## `Order Mass Cancel Request`(`q`)

`Order Mass Cancel Request`(`q`) message will trigger cancellation of a group of orders.

### Arguments

| Tag | Name | Required | Comments |
|---|---|---|---|
| 11 | `ClOrdID` | Yes | Unique ID of Order Mass Cancel Request (q) as assigned by the client. |
| 530 | `MassCancelRequestType` | Yes | Specifies the type of cancellation requested. Supported values: 7 (all orders), 5 (orders by security type), 1 (orders by symbol).  |
| 167 | `SecurityType` | If `MassCancelRequestType`=5 | possible values 'FUT', 'OPT'. The security type for which to cancel orders. |
| 55 | `Symbol` | If `MassCancelRequestType`=1 | The symbols for which to cancel all orders |
| 15 | `Currency` | No | If to cancel only certain currency if applicable. See also [#security-list-y][Security List].|

### Response

After the cancellation, the server responds with a `Order Mass Cancel Report`(`r`).

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 11 | `ClOrdID` | String | Yes | Deribit replaces this field with the own value assigned by the server \(it is not the client id from New Order Single\) |
| 530 | `MassCancelRequestType` | Yes | Specifies the type of cancellation requested. Supported values: 1 (all orders), 5 (orders by security type), 7 (orders by symbol).  |
| 531 | `MassCancelResponse` | No | If successful, echoes the `MassCancelRequestType`. |
| 58 | `Text` | No | 'success', if deletion was successful |
| 532 | `MassCancelRejectReason` | No | Reason why deletion failed. 1=Unknown security, 5=Unknown security type |


## `Order Mass Status Request`(`AF`)

`Order Mass Status Request`(`AF`) message requests the status of currently open orders. The exchange should respond with a series of Execution `Report`(`8`) messages detailing orders.

### Arguments

| Tag | Name | Required | Comments |
|---|---|---|---|
| 584 | `MassStatusReqID` | Yes | Client-assigned unique ID of this request |
| 585 | `MassStatusReqType` | Yes | Specifies the scope of the mass status request. (see below) |

This message can be used in two ways: to request status of all your open orders, or to request the status of a single order (which needn't be open). 

To request the status of all orders, choose a random `MassStatusRequestId`, and set `MassStatusReqType=7`. The server will respond with a series of `Execution Reports`(`8`) messages, where the first message contains `MassStatusReqType=7` and `TotNumReports` will be set to the number of reports to be expected as a follow-up.

To request the status of specific order, set `MassStatusReqType=1`, and set `MassStatusReqId` to the order ID

### Response

When the client requests the status of current orders, the exchange should reply with a series of special `Execution Reports`(`8`), one for every order requested.

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 11 | `ClOrdID` | String | Yes | Deribit replaces this field with the own value assigned by the server \(it is not the client id from New Order Single\) |
| 41 | `OrigClOrdId` | String | Yes | The original value assigned by the client in the `New Order Single`(`D`) message |
| 39 | `OrdStatus` | char | Yes | 0 = New, 1 = Partially filled, 2 = Filled, 8 = Rejected |
| 54 | `Side` | char | Yes | 1 = Buy, 2 = Sell |
| 60 | `TransactTime` |  | Yes | Time the transaction represented by this Execution Report occurred. Fix timestamp. |
| 151 | `LeavesQty` | Qty | Yes | Order quantity open for further execution \(`LeavesQty` = `OrderQty` - `CumQty`\) |
| 14 | `CumQty` | Qty | Yes | Total executed quantity or 0.0 |
| 38 | `OrderQty` | Qty | Yes | Order quantity |
| 40 | `OrdType` | char | Yes | 1 = Market, 2 = Limit, 4 = Stop Limit, S = Stop Market |
| 44 | `Price` | Price | Yes | Price |
| 18 | `ExecInst` | MultipleCharValue | No | Currently is used to mark POST ONLY orders: 6 = "Participate don't initiate", and REDUCE ONLY orders: E = " Do not increase - DNI"  |
| 103 | `OrdRejReason` | int  | Yes |  Code to identify reason for order rejection. |
| 58 | `Text` | String | No | Free format text string, usually exceptions |
| 207 | `SecurityExchange` | String | No | "Deribit" |
| 55 | `Symbol` | String | Yes | Instrument symbol |
| 854 | `QtyType` | String | No | Type of quantity specified in a quantity. Currently only 1 - `Contracts`.  |
| 231 | `ContractMultiplier` | float | No | Specifies a multiply factor to convert from contracts to total units |
| 6 | `AvgPx` | float | No | Average execution price or 0.0 if not executed yet or rejected |
| 210 | `MaxShow` | Qty | No | Maximum quantity (e.g. number of shares) within an order to be shown to other customers |
| 100012 | `DeribitAdvOrderType` | char | No | if it is present then it denotes advanced order for options: 0 = Implied Volatility Order, 1 = USD Order |
| 1188 | `Volatility` | float | No | volatility for Implied Volatility Orders (options orders with fixed volatility) |
| 839 | `PeggedPrice` | Price | No | value of fixed USD price for USD Orders (options orders with fixed USD price) |

When responding to a `MassStatusReqType=7` request, the server precedes the `Execution Reports`(`8`) messages with a special `Execution Reports`(`8`) message:

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 584 | `MassStatusReqID` | String | Yes | The `MassStatusReqID` from the request. (Only for the first message response to a `MassStatusReqType=7` request.) |
| 585 | `MassStatusReqType` | int | Yes | The `MassStatusReqType` from the request. (Only for the first message response to a `MassStatusReqType=7` request.) |
| 911 | `TotNumReports` | int | Yes | The total number of reports following this initial report |



### `Request For Positions`(`AN`)

Request For `Positions`(`AN`) is used by the owner of a position to request a Position Report.

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 710 | `PosReqID` | String |Yes | Unique identifier for the Request for `Positions`(`AN`) as assigned by the submitter. |
| 724 | `PosReqType` | int |Yes | 0 = Positions \(currently\) |
| 263 | `SubscriptionRequestType` | int | No | 0=Receive snapshot, 1=subscribe, 2=unsubscribe |
| 15 | `Currency` | currency| No | To request for certain currency only. If it is missing -- all currencies are reported |

### Response

The server will respond with a Position `Report`(`AP`) message.

## `Position Report`(`AP`)

The Position `Report`(`AP`) message is returned by the holder of a position in response to a Request for `Position`(`AN`) message.

### Arguments

| Tag | Name | Required | Comments |
|---|---|---|---|
| 721 | `PosMaintRptID` | Yes | Unique identifier for this position report |
| 710 | `PosReqID` | No | Unique identifier for the Request for Positions associated with this report. |
| 724 | `PosReqType` | No | 0 = Positions \(currently\) |
| 728 | `PosReqResult` | No | 0 = success, 1 = unsupported request for positions |
| 702 | `NoPositions` | No | Number of position entries following |
| =&gt;704 | `LongQty` | No | Qty for long position \(0 for short position\) |
| =&gt;705 | `ShortQty` | No | Qty for short position \(0 for long position\) |
| =&gt;55 | `Symbol` | No | Instrument symbol |
| =&gt;854 | `QtyType` | No | Type of quantity specified in a quantity. Currently only 1 - `Contracts`.  |
| =&gt;231 | `ContractMultiplier` | No | Specifies a multiply factor to convert from contracts to total units |
| =&gt;883 | `UnderlyingEndPrice` | No | Mark price \(reference price\) |
| =&gt;54 | `Side` | No | 1 = Buy, 2 = Sell |
| =&gt;730 | `SettlPrice` | No | Average price |
| =&gt;96 | `RawData` | No | Additional info, semi-colon separated: maintenance margin;initial margin;floating P/L |
| =&gt;100088 | `DeribitLiquidationPrice` | No | Estimated liquidation price |
| =&gt;100089 | `DeribitSizeInCurrency` | No | Size in the underlying currency, for example BTC or ETH |

## `User Request`(`BE`)

This message is used to request a report on a user's status and user account info.

### Arguments

| Tag | Name | Required | Comments |
|---|---|---|---|
| 923 | `UserRequestID` | Yes | The request ID |
| 924 | `UserRequestType` | Yes | Should be equal to 4 \(Request individual user status\), only `UserRequestType=4` supported for now |
| 553 | `Username` | Yes | API authenticated 'Access Key', user can request only own info, should be the same as for previous `LOGON`(`A`) |
| 15 | `Currency` | No | Currency of the report. See also [#security-list-y][Security List]. Default is BTC.|


### Response

The server will respond with a User `Response`(`BF`) message.




## `User Response`(`BF`)

This message is used to respond to a `USER REQUEST`(`BE`) message, it reports the status of the user and user's account info.

### Response

| Tag | Name | Required | Comments |
|---|---|---|---|
| 923 | `UserRequestID` | Yes | The request ID |
| 553 | `Username` | Yes | User's API 'Access Key' |
| 926 | `UserStatus` | No | 1 = logged in, current implementation accepts USER REQUEST-s only from logged in users |
| 15 | `Currency` | No | Currency of the report. See also [#security-list-y][Security List]. Default is BTC.|
| 100001 | `DeribitUserEquity` | No | Equity of the user |
| 100002 | `DeribitUserBalance` | No | Balance of the user |
| 100003 | `DeribitUserInitialMargin` | No | Initial margin of the user |
| 100004 | `DeribitUserMaintenanceMargin` | No | Maintenance margin of the user |
| 100005 | `DeribitUnrealizedPl` | No | Unrealized P/L of the user |
| 100006 | `DeribitRealizedPl` | No | Realized P/L of the user |
| 100011 | `DeribitTotalPl` | No | Total P/L of the user |
| 100013 | `DeribitMarginBalance` | No | Margin Balance |


## `Order Cancel/Replace Request`(`G`)

To change/edit the parameters of an existing order

### Arguments

| Tag | Name | Type | Required | Comments |
|---|---|---|---|---|
| 41 | `OrigClOrdID` | String | Yes | |
| 11 | `ClOrdId` | String | Yes  |  |
| 60 | `TransactTime` | UTCTimestamp | Yes  | |
| 54 | `Side` | char | Yes  | original side, 1=buy, 2=sell |
| 38 | `OrderQty` | Qty | | order quantity |
| 40 | `OrdType` | char | Yes | currently 2 - 'limit' |
| 44 | `Price` | Price | | order price (for advanced options orders it could be volatility or USD value if applicable) |
| 55 | `Symbol` | String | Yes | instrument name is required from performance reasons. |
| 18 | `ExecInst` | MultipleCharValue | No | Currently is used for POST ONLY orders: 6 = "Participate don't initiate", and REDUCE ONLY orders: E = " Do not increase - DNI"  |

### Response
see New Order Single response 

## `Execution Reports`(`8`) about order changes
### Notification 
The report `Execution Reports`(`8`) is similar to New Order Single or Cancel/Replace responses but it doesn't contain Fills (trades notifications are coming via Marlet Data)

| Tag | Name | Required | Comments |
|---|---|---|---|
| 11 | `ClOrdID` | Yes | Deribit replaces this field with the own value assigned by the server \(it is not the client id from New Order Single\) |
| 41 | `OrigClOrdId` | Yes | The original value assigned by the client in the `New Order Single`(`D`) message |
| 39 | `OrdStatus` | Yes | 0 = New, 1 = Partially filled, 2 = Filled, 8 = Rejected |
| 54 | `Side` | Yes | 1 = Buy, 2 = Sell |
| 60 | `TransactTime` | Yes | Time the transaction represented by this Execution Report occurred. Fix timestamp. |
| 151 | `LeavesQty` | Yes | Order quantity open for further execution \(`LeavesQty` = `OrderQty` - `CumQty`\) |
| 14 | `CumQty` | Yes | Total executed quantity or 0.0 |
| 38 | `OrderQty` | Yes | Order quantity |
| 5127 | `ConditionTriggerMethod` | No | Trigger for a stop order 1 = Mark Price, 2 = Last Price, 3 = corresponding Index Price  
| 40 | `OrdType` | Yes | 1 = Market, 2 = Limit, 4 = Stop Limit, S = Stop Market |
| 44 | `Price` | No | Price, maybe be absent for Market and Stop Market orders |
| 18 | `ExecInst` | No | Currently is used to mark POST ONLY orders: 6 = "Participate don't initiate", and REDUCE ONLY orders: E = " Do not increase - DNI"  |
| 99 | `StopPx`| No | Stop price for stop limit orders | 
| 103 | `OrdRejReason` | Yes |  |
| 58 | `Text` | No | Free format text string, usually exceptions |
| 207 | `SecurityExchange` | No | "Deribit" |
| 55 | `Symbol` | Yes | Instrument symbol |
| 854 | `QtyType` | No | Type of quantity specified in a quantity. Currently only 1 - `Contracts`.  |
| 231 | `ContractMultiplier` | No | Specifies a multiply factor to convert from contracts to total units |
| 6 | `AvgPx` | No | Average execution price or 0.0 if not executed yet or rejected |
| 210 | `MaxShow` | No | Maximum quantity (e.g. number of shares) within an order to be shown to other customers |
| 100012 | `DeribitAdvOrderType` | No | if it is present then it denotes advanced order for options: 0 = Implied Volatility Order, 1 = USD Order |
| 1188 | `Volatility` | No | volatility for Implied Volatility Orders (options orders with fixed volatility) |
| 839 | `PeggedPrice` | No | value of fixed USD price for USD Orders (options orders with fixed USD price) |

 


## Changes Log

### Release 1.3.00

* MarketData (W) and (X): added OpenInterest (746)
* MarketData (W) and (X): added MarkPrice (100090)
* MarketData (W) and (X): added UnderlyingSymbol(311)
* MarketData (W) and (X): added UnderlyingPx(810)
* MarketData (W) and (X): added ContractMultiplier(231)
* Position Report (AP): added ContractMultiplier(231)
* Position Report (AP): added UnderlyingEndPrice(883)
* SecurityList (y): PutOrCall changed for compliance - put = 0, call = 1
* SecurityList (y): added InstrumentPricePrecision(2576)
* SecurityList (y): added MinPriceIncrement(969)
* SecurityList (y): added UnderlyingSymbol(311)
* SecurityList (y): added MinTradeVol(562)
* User Request(BE): added parameter Currency(15), default is BTC
* Order Mass Cancel Request(q): added  parameter Currency(15)
* added notification for StopLimit and StopMarket Orders. StopMarket orders has OrdType=S
* Execution Report (8): added ContractMultiplier(231)
* Execution Report (8): added ConditionTriggerMethod(5127)  
